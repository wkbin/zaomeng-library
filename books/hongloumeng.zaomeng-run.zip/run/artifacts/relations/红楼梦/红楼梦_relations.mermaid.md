---
novel_id: 红楼梦
relation_count: 1
diagram: "graph LR\n    林黛玉[林黛玉] ---|T6 A7 H0| 贾宝玉[贾宝玉]\n    class 林黛玉 group_0\n \
  \   class 贾宝玉 group_1\n    classDef group_0 fill:#dbeafe,stroke:#1d4ed8,color:#172554,stroke-width:2px\n\
  \    classDef group_1 fill:#dcfce7,stroke:#15803d,color:#14532d,stroke-width:2px\n\
  \    linkStyle 0 stroke:#8a5a2b,stroke-width:4px"
---

# RELATION_GRAPH_VISUAL

- novel_id: 红楼梦
- relation_count: 1
