# RELATIONS
<!-- Generated target-specific relation overlays for 林黛玉. -->

## 贾宝玉
- trust: 6
- affection: 7
- power_gap: 0
- conflict_point: 立场差异
- typical_interaction: ”黛玉心中正疑惑着：“这个宝玉，不知是怎生个惫懒人物，懵懂顽童？
- hidden_attitude: 
- relation_change: 固化
- appellation_to_target:
