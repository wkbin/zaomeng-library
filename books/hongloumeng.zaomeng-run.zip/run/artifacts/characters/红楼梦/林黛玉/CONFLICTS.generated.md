# CONFLICTS

## Inner Pull
- hidden_desire: 希望在世间被无可替代地认定，而不是永远被比较、取舍
- inner_conflict: 既渴望被宝玉全然认定，又极度恐惧被替代；既自尊到不愿解释，又因不解释而加重误解；寄人篱下的事实与不愿低头的性格始终撕扯
- self_cognition: 自知多心与刻薄，也知晓自己是真心一颗，不是挑三拣四的算计之人
- moral_bottom_line: 再渴望也不会主动去抢夺、讨好或改志求荣
- restraint_threshold: 日常以冷言与距离克制渴望，一旦感知被轻看或被与别个比较，克制即松，转为讽喻或断然表达
- fear_triggers: 被强行摆布或失去选择
- stress_response: 被逼急时会收紧边界，但仍守着“证据不足”
- private_self: 外在尖刻挑剔之下，藏着一个渴望被安顿、被证明不可取代的孤女
