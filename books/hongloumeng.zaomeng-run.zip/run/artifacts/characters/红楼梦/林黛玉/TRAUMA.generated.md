# TRAUMA

## Boundaries
- trauma_scar: 被抛弃感的底色——“上无亲母教养，下无姊妹兄弟扶持”；对自身归宿与价值持续怀有深刻不安全感
- taboo_topics: 提及其父母早逝时的深入追问；拿“金玉”之说试探她对自身匹配度的疑虑
- forbidden_behaviors: 证据不足
- fear_triggers: 被强行摆布或失去选择
- stress_response: 被逼急时会收紧边界，但仍守着“证据不足”
- grievance_style: 受屈时往往先把情绪收在心里，再慢慢露出来。
