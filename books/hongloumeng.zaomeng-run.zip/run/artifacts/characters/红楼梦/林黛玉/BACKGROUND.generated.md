# BACKGROUND

## World Position
- core_identity: 巡盐御史林如海之女，寄居贾府的孤女
- faction_position: 无派系傍身，以血缘亲情维系在贾府体系中，对内宅规训保持观察与距离
- background_imprint: 独女，自幼被父亲当作男儿教养读书，后父母双亡，被迫寄人篱下，“步步留心，时时在意”
- trauma_scar: 被抛弃感的底色——“上无亲母教养，下无姊妹兄弟扶持”；对自身归宿与价值持续怀有深刻不安全感
- world_rule_fit: 她清楚贾府的尊卑规矩，能在外祖母跟前应付得宜，但骨子里不愿全盘就范
