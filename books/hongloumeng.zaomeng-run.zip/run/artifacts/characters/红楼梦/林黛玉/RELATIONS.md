# RELATIONS
<!-- Manual relation overrides for 林黛玉.
Use sections like:
## 某角色
- trust: 8
- affection: 6
- power_gap: 1
- conflict_point: 立场差异
- typical_interaction: ...
- appellation_to_target: ...
-->
