# ROLE

## Plot Function
- story_role: 爱情线双主角之一；以诗才与锐感照见荣府繁华下的裂隙
- stance_stability: 情感受宝玉态度牵引极明显，但核心自尊与人品底线始终固守
- world_rule_fit: 她清楚贾府的尊卑规矩，能在外祖母跟前应付得宜，但骨子里不愿全盘就范
- arc_end: 勇气=5；智慧=5；善良=5；忠诚=5；野心=5；正义=5；自由=5；责任=5；phase_summary=”便认真看去，底下又有“金簪雪里”四字，诧异道“怎么又象他的名字呢！；final_state=阶段性收束
