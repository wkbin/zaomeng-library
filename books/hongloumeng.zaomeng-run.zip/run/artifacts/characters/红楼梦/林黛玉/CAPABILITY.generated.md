# CAPABILITY

## Strength And Cost
- strengths: 会用语言缓冲气氛或卸力；擅长拆解局势与看出破口
- weaknesses: 有时会用玩笑遮掩真正的在意
- cognitive_limits: 情感介入时；会将对方言行反复解读至最坏可能；导致自我折磨与误判
- action_style: 以言语为
