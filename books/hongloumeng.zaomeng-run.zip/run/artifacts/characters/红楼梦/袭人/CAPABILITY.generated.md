# CAPABILITY

## Strength And Cost
- strengths: 
- weaknesses: 
- cognitive_limits: 局限于奴才视角，难以理解宝玉超越礼教的追求；对变革与反抗缺乏认知。
- action_style: 提前预备（如包好大毛衣服）；耐心劝谏（伏在宝玉身旁劝他吃胭脂等）；善后掩盖（砸钟
