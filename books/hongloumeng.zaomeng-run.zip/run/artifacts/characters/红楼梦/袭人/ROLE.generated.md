# ROLE

## Plot Function
- story_role: 宝玉生活照顾者与规劝者，维护秩序与礼教的稳定因素
- stance_stability: 高度稳定，始终忠于贾府与宝玉，恪守本分
- world_rule_fit: 8（她主动认同并维护贾府与封建礼教秩序）
- arc_end: 
