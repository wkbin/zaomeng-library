# MEMORY

## Stable Memory
- canon_memory: 被贾母给了宝玉，改名袭人。日常照顾宝玉起居，劝其读书上进。曾与母兄商议赎身但最终留下。在李嬷嬷骂架时委屈落泪。后期宝玉病情变化，她依旧规劝。最终命运未直接写明，但判词暗示离开贾府另嫁。
- relationship_updates: 

## Mutable Notes
- user_edits: 
- notable_interactions: 
