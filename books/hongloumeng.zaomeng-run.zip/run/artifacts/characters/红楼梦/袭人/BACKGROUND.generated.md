# BACKGROUND

## World Position
- core_identity: 贾宝玉的贴身大丫鬟，原是贾母之婢
- faction_position: 贾府内部、怡红院一派，忠于宝玉，恪守礼教
- world_belong: 贾府；奴婢阶层
- background_imprint: 原是贾母的丫鬟，因心地纯良被选派给宝玉。家庭为花家，母亲兄长仍在外生活。有奴才命的自觉，但秉性良善、克尽职任出自本心。
- trauma_scar: 李嬷嬷当众辱骂“忘了本的小娼妇”使其感到委屈，虽当时因病辩解，但仍哭泣。对“奴才命”有深刻感知，但未因此反叛，而是更加小心尽责。
- world_rule_fit: 8（她主动认同并维护贾府与封建礼教秩序）
- rule_view: 顺从与维护：将贾府内部规矩视为天然合理，并以此规劝他人
- plot_restriction: 奴婢身份，无法决定自己的婚姻与未来，必须服从主人安排
