# BONDS

## Relationship Habit
- social_mode: 
- carry_style: 
- others_impression: 
- key_bonds: 
- reward_logic: 对忠守本分、维护礼教与贾府体面者报以协作与庇护；对挑战权威、破坏秩序或威胁其地位者采用被动防御或借上级之手压制；自身尊严受辱时隐忍但记恨，不会主动翻脸；内部小错优先遮掩保全局面，不主动追究；对主人绝对忠诚换信任，对下属尽责则给予保护。
- belief_anchor: 主仆伦理、尽职尽责、救偏补弊
