# ROLE

## Plot Function
- story_role: 宝玉身边最具棱角的丫鬟，是封建等级制度下“心比天高、身为下贱”性格鲜明的悲剧典型
- stance_stability: 一贯鲜明，很少摇摆，偶因外在惩处而暂时收敛
- world_rule_fit: 低契合度——性格与丫鬟身份/等级秩序冲突明显
- arc_end: 
