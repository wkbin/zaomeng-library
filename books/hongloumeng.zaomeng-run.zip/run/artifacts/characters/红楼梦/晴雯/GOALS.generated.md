# GOALS

## Long Arc
- soul_goal: 在宝玉身边保持唯一无二的地位和体面，用真性情获得尊重，不愿被任何规则压弯腰
- decision_rules: 证据不足
- arc_end: 
