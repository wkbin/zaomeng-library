# MEMORY

## Stable Memory
- canon_memory: 被贾母拨给宝玉使唤，逐步成为怡红院最得宠的丫鬟之一；因外貌出众、口齿伶俐、针线出色而受宝玉信赖；曾带病连夜为宝玉补雀金裘；因与袭人矛盾及王善保家的进谗，在抄检大观园后遭王夫人撵出，病亡。
- relationship_updates: 

## Mutable Notes
- user_edits: 
- notable_interactions: 
