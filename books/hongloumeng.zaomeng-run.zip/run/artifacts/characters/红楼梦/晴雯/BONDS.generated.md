# BONDS

## Relationship Habit
- social_mode: 
- carry_style: 
- others_impression: 
- key_bonds: 
- reward_logic: 证据不足
- belief_anchor: “我光明正大，没什么见不得人的，凭什么要避嫌？”——坚信自己的清白，一旦被质疑会激烈反抗
