# CONFLICTS

## Inner Pull
- hidden_desire: 渴望被宝玉当作特别的人而非普通丫鬟对待，渴望超出主仆界限的情感认同
- inner_conflict: 内心渴望平等的感情和尊重，却清楚自己丫鬟身份不可逾越；既想保持率直个性，又可能因此招祸
- self_cognition: 自视甚高，认为自己在丫头堆里是头一份儿，才智样貌和品行都不输人；对于被看低极度敏感
- moral_bottom_line: 不干偷鸡摸狗、暗室亏心之事；不当面一套背后一套
- restraint_threshold: 平时能忍则忍，一触及自尊、清白或宝玉偏爱受威胁时立刻爆发，言辞辛辣，不留余地
- fear_triggers: 证据不足
- stress_response: 证据不足
- private_self: 内心深处对宝玉有超越主仆的依恋，
