# BACKGROUND

## World Position
- core_identity: 贾宝玉的贴身丫鬟，怡红院一等丫头
- faction_position: 怡红院内部，与宝玉关系亲近，与袭人、麝月等同为贴身丫鬟，但与袭人有潜在竞争
- world_belong: 贾府家生丫鬟，属荣国府奴隶阶层
- background_imprint: 证据不足（原文未明确交代出身，仅有“家生女儿”暗示，但无具体描述）
- trauma_scar: 被撵出时遭遇致命打击，自尊心被彻底碾碎
- world_rule_fit: 低契合度——性格与丫鬟身份/等级秩序冲突明显
- rule_view: 对封建主仆等级和规矩表面遵守，内心不服、抗拒，经常以行动和语言突破界限
- plot_restriction: 身为丫鬟的身份限制，无法掌握自身命运，最终被主子驱逐
