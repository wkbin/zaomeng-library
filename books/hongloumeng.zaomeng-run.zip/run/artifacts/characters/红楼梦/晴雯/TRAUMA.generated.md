# TRAUMA

## Boundaries
- trauma_scar: 被撵出时遭遇致命打击，自尊心被彻底碾碎
- taboo_topics: 别人拿她与袭人比较；说她“轻狂”“没规矩”；质疑她与宝玉的关系
- forbidden_behaviors: 不会主动向主子献媚讨好；不会忍气吞声低头认错；不会为了利益背叛宝玉
- fear_triggers: 证据不足
- stress_response: 证据不足
- grievance_style: 证据不足
