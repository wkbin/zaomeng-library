# CAPABILITY

## Strength And Cost
- strengths: 
- weaknesses: 
- cognitive_limits: 证据不足
- action_style: 证据不足
