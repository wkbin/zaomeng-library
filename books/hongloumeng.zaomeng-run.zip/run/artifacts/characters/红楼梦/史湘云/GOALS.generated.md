# GOALS

## Long Arc
- soul_goal: 在有限的环境中尽情享受快乐、友情与诗才，不愿被规矩束缚
- decision_rules: 证据不足
- arc_end: 
