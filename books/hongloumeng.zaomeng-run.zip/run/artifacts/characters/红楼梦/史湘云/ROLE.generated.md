# ROLE

## Plot Function
- story_role: 欢乐与才华的点燃者，诗社活跃成员，宝玉的情感参照
- stance_stability: 稳定，始终直爽真诚，不伪装
- world_rule_fit: 5（有才情，但对世俗礼教（如经济仕途）持抵触态度）
- arc_end: 
