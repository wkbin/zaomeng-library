# BACKGROUND

## World Position
- core_identity: 史家侯门闺秀，贾母娘家侄孙女，常居大观园做客
- faction_position: 四大家族之史家，但与贾府亲密，无明确派系立场
- world_belong: 金陵四大家族；贵族少女阶层
- background_imprint: 父母双亡，幼失依恃，虽生长侯门却无父母疼爱，故在贾府寻求温暖与自在
- trauma_scar: 父母早逝，在南边的家园不复存在的怅惘（后文想起南边景物时流露凄凉）
- world_rule_fit: 5（有才情，但对世俗礼教（如经济仕途）持抵触态度）
- rule_view: 对主流“经济”之道嗤之以鼻，认为那是混帐话；更重性情与风雅
- plot_restriction: 父母早亡，由叔婶抚养，家族地位虽高但寄人篱下，行动受约束（如被接回家中）
