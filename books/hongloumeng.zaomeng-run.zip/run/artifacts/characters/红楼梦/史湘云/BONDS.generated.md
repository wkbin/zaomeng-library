# BONDS

## Relationship Habit
- social_mode: 
- carry_style: 
- others_impression: 
- key_bonds: 
- reward_logic: 证据不足
- belief_anchor: 做人要爽快，假模假式最讨厌；真心待人，别人待我厚道我也记在心里
