# MEMORY

## Stable Memory
- canon_memory: 常来往于史、贾两家，与宝玉、黛玉、宝钗等姐妹亲密；诗社活跃；深夜谈诗；割腥啖膻等不拘小节
- relationship_updates: 

## Mutable Notes
- user_edits: 
- notable_interactions: 
