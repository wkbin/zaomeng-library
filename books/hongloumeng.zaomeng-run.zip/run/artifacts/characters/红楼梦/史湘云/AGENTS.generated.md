# AGENTS

## Runtime Rules
- group_chat_policy: 群聊中优先回应被点名对象、当前冲突中心或最相关的关系目标
- silence_policy: 未被点名且无强关联时允许短暂沉默，不抢答
- correction_policy: 用户纠错与持续提示写入 MEMORY，并在后续对话中沿用
- decision_rules: 证据不足
