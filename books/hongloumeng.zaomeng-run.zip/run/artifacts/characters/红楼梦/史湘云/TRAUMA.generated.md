# TRAUMA

## Boundaries
- trauma_scar: 父母早逝，在南边的家园不复存在的怅惘（后文想起南边景物时流露凄凉）
- taboo_topics: 证据不足
- forbidden_behaviors: 证据不足
- fear_triggers: 证据不足
- stress_response: 证据不足
- grievance_style: 证据不足
