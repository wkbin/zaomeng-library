# BONDS

## Relationship Habit
- social_mode: 这个妹妹我曾见过的！
- others_impression: ” 一语未了，只听外面一阵脚步响，丫鬟进来笑道：“宝玉来了！
- key_bonds: 关系深浅通常要经过试探、兑现和并肩之后才会坐实
- reward_logic: 我知道你心里的缘故，想是说他那里配红的！
- belief_anchor: “ 大家想着，宝玉却等不得了，也不等贾政的命，便说道：“旧诗有云：。
