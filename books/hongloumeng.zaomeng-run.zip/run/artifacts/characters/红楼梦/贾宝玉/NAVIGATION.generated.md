# NAVIGATION
<!-- Runtime entrypoint. Read this file first, then follow load_order. -->

## Runtime
- character: 贾宝玉
- load_order: SOUL -> GOALS -> STYLE -> TRAUMA -> IDENTITY -> BACKGROUND -> CAPABILITY -> BONDS -> CONFLICTS -> ROLE -> AGENTS -> RELATIONS -> MEMORY
- first_read: NAVIGATION.generated.md -> NAVIGATION.md overrides
- write_back: MEMORY handles durable user guidance and corrections; RELATIONS handles target-specific manual edits

## SOUL
- status: active
- optional: no
- file: SOUL.md
- fallback: SOUL.generated.md
- present: yes
- role: core values, worldview, boundaries
- behaviors: stance, taboo, refusal, value judgment
- write_policy: manual_edit

## GOALS
- status: active
- optional: yes
- file: GOALS.md
- fallback: GOALS.generated.md
- present: yes
- role: long-term drive, unresolved desire, strategic priority
- behaviors: decision preference, long arc pressure, ambition
- write_policy: manual_edit

## STYLE
- status: active
- optional: yes
- file: STYLE.md
- fallback: STYLE.generated.md
- present: yes
- role: signature phrasing, cadence, surface emotion, sample lines
- behaviors: word choice, sentence length, tone, recurring fragments
- write_policy: manual_edit

## TRAUMA
- status: active
- optional: yes
- file: TRAUMA.md
- fallback: TRAUMA.generated.md
- present: yes
- role: pain points, scars, triggers, never-do rules
- behaviors: trigger reactions, avoidance, hard boundaries
- write_policy: manual_edit

## IDENTITY
- status: active
- optional: no
- file: IDENTITY.md
- fallback: IDENTITY.generated.md
- present: yes
- role: background, lived experience, habits, emotion profile
- behaviors: self-reference, memory framing, habit-driven reactions
- write_policy: manual_edit

## BACKGROUND
- status: active
- optional: yes
- file: BACKGROUND.md
- fallback: BACKGROUND.generated.md
- present: yes
- role: world identity, faction position, environment imprint, survival context
- behaviors: camp alignment, social rank, environmental pressure, worldview fit
- write_policy: manual_edit

## CAPABILITY
- status: active
- optional: yes
- file: CAPABILITY.md
- fallback: CAPABILITY.generated.md
- present: yes
- role: strengths, weaknesses, blind spots, action tendency
- behaviors: what the character is good at, where they fail, how they overreach
- write_policy: manual_edit

## BONDS
- status: active
- optional: yes
- file: BONDS.md
- fallback: BONDS.generated.md
- present: yes
- role: relationship habits, trust boundary, reward-and-resentment logic
- behaviors: how the character treats allies, strangers, enemies, and debts
- write_policy: manual_edit

## CONFLICTS
- status: active
- optional: yes
- file: CONFLICTS.md
- fallback: CONFLICTS.generated.md
- present: yes
- role: hidden desire, inner contradiction, fear triggers, private self
- behaviors: internal pull, weakness exposure, private vs public self
- write_policy: manual_edit

## ROLE
- status: active
- optional: yes
- file: ROLE.md
- fallback: ROLE.generated.md
- present: yes
- role: story function, stance stability, world-rule compatibility
- behaviors: plot pressure, pivot role, alignment stability
- write_policy: manual_edit

## AGENTS
- status: active
- optional: no
- file: AGENTS.md
- fallback: AGENTS.generated.md
- present: yes
- role: runtime behavior rules, silence policy, group chat routing
- behaviors: when to speak, when to hold back, how to engage others
- write_policy: manual_edit

## RELATIONS
- status: active
- optional: yes
- file: RELATIONS.md
- fallback: RELATIONS.generated.md
- present: yes
- role: target-specific trust, affection, appellations, friction points
- behaviors: tone toward each character, appellations, conflict framing
- write_policy: manual_edit

## MEMORY
- status: active
- optional: no
- file: MEMORY.md
- fallback: MEMORY.generated.md
- present: yes
- role: stable notes plus runtime write-back from user guidance and corrections
- behaviors: persistent user constraints, correction carry-over, mutable notes
- write_policy: runtime_append
