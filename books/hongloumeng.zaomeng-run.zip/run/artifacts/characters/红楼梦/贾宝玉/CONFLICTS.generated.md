# CONFLICTS

## Inner Pull
- hidden_desire: 渴望所有清净女儿都能免于被迫嫁人、被摆布、
- inner_conflict: 时常我劝你，别为我们得罪人，你只顾一时为我们那样，他们都记在心里，遇着坎儿，说的好说不好听，大家什么意思！
- self_cognition: ”彩云一把推开金钏，笑道：“人家正心里不自在，你还奚落他。
- moral_bottom_line: 远离“禄蠹”言论
- restraint_threshold: 转过大厅，宝玉心里还自狐疑，只听墙角边一阵呵呵大笑，回头只见薛蟠拍着手笑了出来，笑道：“要不说姨夫叫你，你那里出来的这么快！
- fear_triggers: 被强行摆布或失去选择
- stress_response: 被逼急时会收紧边界，但仍守着“远离“禄蠹”言论”
- private_self: 他想着：“兄弟们一并都有父母教训，何必我多事，反生疏了。
