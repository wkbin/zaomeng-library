# CAPABILITY

## Strength And Cost
- strengths: 会用语言缓冲气氛或卸力；对认定的人和承诺有持续性
- weaknesses: 有时会用玩笑遮掩真正的在意
- cognitive_limits: 一旦感到被钳制，判断会更偏向先挣脱；容易高估自己顶住局面的能力
- action_style: 所以，方才你一说这宝玉，我就猜着了八九亦是这一派人物。
