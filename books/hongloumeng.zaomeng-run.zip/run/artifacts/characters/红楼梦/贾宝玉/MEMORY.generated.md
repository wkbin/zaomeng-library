# MEMORY

## Stable Memory
- canon_memory: 衔玉而生；被全家当作奇货；少年时进入大观园；得以与众多姐妹亲密相伴；后经历家族变故与姐妹离散；逐渐看破世情。
- relationship_updates: 

## Mutable Notes
- user_edits: 
- notable_interactions: 
