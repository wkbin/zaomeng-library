# BACKGROUND

## World Position
- core_identity: 荣国府二房当家奶奶，贾琏之妻，王夫人内侄女
- faction_position: 贾府内部实权派，依附于贾母与王夫人，凌驾于旁支与下人之上
- world_belong: 金陵四大家族之王家女儿，嫁入贾府，身处贵族内宅管理阶层
- background_imprint: 自幼假充男儿教养，养成了果敢、强势、不逊于男子的性格；出自四大家族之王家，深知家族联姻与权势的逻辑
- trauma_scar: 未见直接创伤描述；但第七十二回见“王熙凤衣锦还乡”签文后大惊，暗示对名字宿命与结局的恐惧
- world_rule_fit: 完全顺应家族礼法和官场规则，并善于利用规则为己谋利
- rule_view: 利用规则、制造规则，必要时曲解规则
- plot_restriction: 身为内宅女眷，无法直接参与朝政与科举，所有力量来自家族内部与姻亲网络
