# ROLE

## Plot Function
- story_role: 贾府日常管理的实际执行者；外部矛盾的抵御者；内部利益的捍卫者；后期由盛转衰的关键见证人
- stance_stability: 始终以保权、获利为核心，立场极为稳定，后期因健康和失利而略有松动但底色不变
- world_rule_fit: 完全顺应家族礼法和官场规则，并善于利用规则为己谋利
- arc_end: 
