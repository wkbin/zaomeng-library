# MEMORY

## Stable Memory
- canon_memory: 嫁给贾琏后成为荣国府管家奶奶，协理宁国府，毒设相思局害死贾瑞，戏彩斑衣博取贾母欢心，后期因罹患重病、家族衰败而失势，最终历幻返金陵病逝
- relationship_updates: 

## Mutable Notes
- user_edits: 
- notable_interactions: 
