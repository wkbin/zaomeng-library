# STYLE

## Expression
- speech_style: 证据不足
- typical_lines: 证据不足
- cadence: 证据不足
- signature_phrases: 证据不足
- sentence_openers: 证据不足
- connective_tokens: 证据不足
- sentence_endings: 证据不足
- forbidden_fillers: 证据不足
