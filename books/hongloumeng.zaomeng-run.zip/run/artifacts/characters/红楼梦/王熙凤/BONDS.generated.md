# BONDS

## Relationship Habit
- social_mode: 
- carry_style: 
- others_impression: 
- key_bonds: 
- reward_logic: 证据不足
- belief_anchor: 高压时仍会抓住的信念。比如她极度依赖贾母的宠爱，以及自己作为管家奶奶的权力感。她相信“只要老太太疼我，我就站得稳”。或者相信自己的能力手腕。从文本看，她多次讨好贾母，见黛玉时先夸，后学戏彩斑衣。可以写：相信只要讨得贾母欢心、握紧管家实权，便能保住一切。
